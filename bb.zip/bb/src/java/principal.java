/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Darlan
 */
@WebServlet(urlPatterns = {"/principal"})
public class principal extends HttpServlet {
    
    private ResultSet resultado = null;
    private PreparedStatement pr_consulta = null;
    private  Connection conexao;
    private static Connection con = null;


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        try{
        String dbName = "teste";String userName = "root"; String password = "";
        String hostname = "localhost";String port = "3306";
        String jdbcUrl = "jdbc:mysql://" + hostname + ":"
         + port + "/" + dbName + "?user=" + userName + "&password=" + password+"&autoReconnect=true";
        Class.forName("com.mysql.jdbc.Driver");
        con = DriverManager.getConnection(jdbcUrl);
          PrintWriter out = response.getWriter();
          this.conexao = con;
          int op = Integer.parseInt(request.getParameter("op"));  
          if(op == 1){
                String sql = "INSERT INTO `ContaCorrente` (`idContaCorrente`,`NumeroConta`,`CPF_Titular`) VALUES (NULL, '" + request.getParameter("conta")+ "', '" + request.getParameter("cpf") + "')";
                pr_consulta = conexao.prepareStatement(sql);
                pr_consulta.execute(sql);
                out.println("<p>Conta cadastrada.</p><br><a href='/bb'>Voltar");
          }
          
          if(op == 2){
                 int id = 0;         
                 String sql = "SELECT * FROM ContaCorrente WHERE `NumeroConta` = '" +request.getParameter("conta")+ "'";
                 pr_consulta = conexao.prepareStatement(sql);
                 resultado = pr_consulta.executeQuery();
                 while (resultado.next()) {
                    id = resultado.getInt("idContaCorrente");
                 }
              	DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss"); Date dataAtual = new Date();
                 String sql2 = "INSERT INTO `Operacao` (`idOperacao`, `DataOperacao`, `ValorOperacao`, `CPFResponsavelOperacao`, `idContaCorrente`) VALUES(NULL, '" + new java.sql.Date(dataAtual.getTime()) + "', '" + request.getParameter("valor")+ "','" + request.getParameter("cpf")+ "','" + id + "')";
                pr_consulta = conexao.prepareStatement(sql2);
                pr_consulta.execute(sql2);
                out.println("<p>Cadastrado.</p><br><a href='/bb'>Voltar");
               
            
          }
          
          if(op == 3){
                int id = 0;
                String titular_cpf = "";String conta= "";String credito_debito;String soma = "";
                String sql = "SELECT * FROM ContaCorrente WHERE `NumeroConta` = '" +request.getParameter("conta")+ "'";
                 pr_consulta = conexao.prepareStatement(sql);
                 resultado = pr_consulta.executeQuery();
                 while (resultado.next()) {
                    id = resultado.getInt("idContaCorrente");
                    titular_cpf =  resultado.getString("CPF_Titular");
                    conta = resultado.getString("NumeroConta");
            
                                       
                 }
                 String resultado = "<p>Número da conta:"+conta+"</p>";
                        resultado += "<p>cpf:"+titular_cpf+"</p>";

                
                 String sql2 = "SELECT * FROM `Operacao` WHERE `idContaCorrente` ="+id+" ORDER BY `Operacao`.`DataOperacao` ASC";
                 pr_consulta = conexao.prepareStatement(sql2);
                 this.resultado = pr_consulta.executeQuery();
                 
                 while (this.resultado.next()) {
                     credito_debito = (this.resultado.getBigDecimal("ValorOperacao").compareTo(new BigDecimal(0)) < 0) ? "Débito":"Credito";
                     resultado += "<tr>\n<td>"+this.resultado.getBigDecimal("ValorOperacao")+"</td>\n<td>"+this.resultado.getString("CPFResponsavelOperacao")+"</td>\n<td>"+credito_debito +"</td>\n<td>"+this.resultado.getDate("DataOperacao")+"</td>\n</tr><br>\n";
               }
                 
                 String sql3 = "SELECT SUM(ValorOperacao) as soma FROM `Operacao` WHERE `idContaCorrente` = "+id+"";
                 pr_consulta = conexao.prepareStatement(sql3);
                 this.resultado = pr_consulta.executeQuery();
                 
                 while (this.resultado.next()) {
                    soma = this.resultado.getString("soma");
                       
                }
                out.println(resultado+"<br>Saldo total:"+soma+"<br><a href='/bb'>Voltar");
                
          }
          
          
        } catch (SQLException ex) {
            Logger.getLogger(principal.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

 

}
